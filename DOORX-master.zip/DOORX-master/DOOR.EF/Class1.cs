﻿namespace DOOR.EF
{
    public class Class1
    {

    }
}