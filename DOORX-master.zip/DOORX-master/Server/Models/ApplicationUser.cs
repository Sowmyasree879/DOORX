﻿using Microsoft.AspNetCore.Identity;

namespace DOOR.Server.Models;

public class ApplicationUser : IdentityUser
{
}
