﻿namespace DOOR.Client.eNums
{
    public enum eNumTelerikThemeColor
    {
        primary,
        secondary,
        tertiary,
        info,
        success,
        warning,
        error,
        dark,
        light,
        inverse
    }
}
